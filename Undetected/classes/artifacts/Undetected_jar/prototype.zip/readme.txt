Undetected - Gameplay Prototype

by. 7studio

Introduction: This is the gameplay prototype for our game "Undetected". It includes several gameplay mechanics such as character movements, box interactions, lasers, objective objects, and win condition. 


Gameplay: The players' goal is to reach the key at the top left corner of the map and return to the starting platform. The players will lose if the player character runs into the lasers. The player character is controlled by arrow keys and nearby boxes can be picked up using the space key.